### 定制的日历组件
重写了大部分代码，保留了核心代码
同时根据需求加入了按周选择
### 参考：[前端小白如何用 JavaScript 写一个简单日历](http://www.jianshu.com/p/4fea34254dff)